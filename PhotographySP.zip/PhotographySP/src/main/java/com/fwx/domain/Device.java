package com.fwx.domain;

public class Device {
    private String id;

    private String deviceName;

    private String deviceNo;

    private String deviceStatus;

    private Integer devicePrice;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName == null ? null : deviceName.trim();
    }

    public String getDeviceNo() {
        return deviceNo;
    }

    public void setDeviceNo(String deviceNo) {
        this.deviceNo = deviceNo == null ? null : deviceNo.trim();
    }

    public String getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(String deviceStatus) {
        this.deviceStatus = deviceStatus == null ? null : deviceStatus.trim();
    }

    public Integer getDevicePrice() {
        return devicePrice;
    }

    public void setDevicePrice(Integer devicePrice) {
        this.devicePrice = devicePrice;
    }
}