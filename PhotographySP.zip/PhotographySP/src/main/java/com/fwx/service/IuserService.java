package com.fwx.service;

/*
 * 用户管理的服务层
 */
public interface IuserService {

	/*用户登录*/
	public boolean login(String username, String password);

}
